#include "addbox.h"
#include "ui_addbox.h"

addBox::addBox(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::addBox)
{
    ui->setupUi(this);
   connect(ui->pushButton,&QPushButton::clicked,this,&addBox::button2);
}

addBox::~addBox()
{
    delete ui;
}

void addBox::button2()
{
    QString Book_name=ui->lineEdit->text();
    QString Book_author=ui->lineEdit_2->text();
    QString Book_price=ui->lineEdit_3->text();
   emit  getVal(Book_name,Book_author,Book_price);
}

