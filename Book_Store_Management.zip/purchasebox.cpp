#include "purchasebox.h"
#include "ui_purchasebox.h"

purchaseBox::purchaseBox(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::purchaseBox)
{
    ui->setupUi(this);
    connect(ui->pushButton, &QPushButton::clicked,this,&purchaseBox::pur);
}

purchaseBox::~purchaseBox()
{
    delete ui;
}

void purchaseBox::pur()
{
    QString userName=ui->lineEdit->text();
    QString quantity=ui->lineEdit_2->text();
    emit getPur(userName,quantity);
}

