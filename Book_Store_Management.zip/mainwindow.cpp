#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QStringList>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QFile>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , addbox(new addBox(this))
    , purbox(new purchaseBox(this))
{
    ui->setupUi(this);

    // Hardcoded SQLite database file path
    QString dbPath = "C:/Book_Store_Management_System/Book_Store.db";

    // Set up and open the database
    if (!QSqlDatabase::isDriverAvailable("QSQLITE")) {
        QMessageBox::critical(this, "Error", "SQLite driver not available.");
        return;
    }

    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbPath);

    if (!db.open()) {
        QMessageBox::critical(this, "Error", "Failed to open the database! Error: " + db.lastError().text());
        return;
    }

    // Hardcoded SQL query to create BookList table if not exists
    QSqlQuery query;
    if (!query.exec("CREATE TABLE IF NOT EXISTS BookList ("
                    "Id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    "Book_Name TEXT, "
                    "Author TEXT, "
                    "Price INTEGER)")) {
        QMessageBox::critical(this, "Error", "Failed to create table: " + query.lastError().text());
    } else {
        qDebug() << "Table created successfully or already exists.";
    }

    // Set up connections for buttons and signals
    connect(ui->pushButton, &QPushButton::clicked, this, &MainWindow::button1);
    connect(addbox, &addBox::getVal, this, &MainWindow::onAdd);
    connect(ui->pushButton_2, &QPushButton::clicked, this, &MainWindow::purFun);
    connect(purbox, &purchaseBox::getPur, this, &MainWindow::onPurchase);
}

MainWindow::~MainWindow()
{
    delete ui;
    delete addbox;
    delete purbox;

    // Close and remove the database connection
    QSqlDatabase db = QSqlDatabase::database();
    if (db.isOpen()) {
        db.close();
    }
    QSqlDatabase::removeDatabase(QSqlDatabase::defaultConnection);
}

void MainWindow::button1()
{
    addbox->show();
}

void MainWindow::onAdd(const QString &n, const QString &author, const QString &p)
{
    QSqlDatabase db = QSqlDatabase::database(); // Get the existing database connection

    if (!db.isOpen()) {
        QMessageBox::critical(this, "Error", "Database connection is not open.");
        return;
    }

    QSqlQuery query;
    query.prepare("INSERT INTO BookList (Book_Name, Author, Price) VALUES (:name, :author, :price)");

    query.bindValue(":name", n);
    query.bindValue(":author", author);

    bool ok;
    int priceInt = p.toInt(&ok);
    if (!ok) {
        QMessageBox::critical(this, "Error", "Invalid price input.");
        return;
    }
    query.bindValue(":price", priceInt);

    if (!query.exec()) {
        qDebug() << "Query execution failed: " << query.lastError().text();  // Debugging query failure
        QMessageBox::critical(this, "Error", "Failed to add the book. Error: " + query.lastError().text());
    } else {
        QMessageBox::information(this, "Success", "New Book Added Successfully!");
    }
}

void MainWindow::purFun()
{
    purbox->show();
}

void MainWindow::onPurchase(const QString &n, const QString &q)
{
    QSqlDatabase db = QSqlDatabase::database();

    if (!db.isOpen()) {
        QMessageBox::critical(this, "Error", "Database connection is not open.");
        return;
    }

    bool ok;
    int quantity = q.toInt(&ok);
    if (!ok) {
        QMessageBox::critical(this, "Error", "Invalid quantity input.");
        return;
    }

    QSqlQuery query;
    query.prepare("SELECT Price FROM BookList WHERE Book_Name = :name");
    query.bindValue(":name", n);

    if (!query.exec()) {
        qDebug() << "Query execution failed: " << query.lastError().text();  // Debugging query failure
        QMessageBox::critical(this, "Error", "Failed to execute query. Error: " + query.lastError().text());
        return;
    }

    if (query.next()) {
        int price = query.value(0).toInt();
        int bill = price * quantity;
        QMessageBox::information(this, "Success", "Total Bill: " + QString::number(bill));
    } else {
        QMessageBox::information(this, "Error", "Book Not Found.");
    }
}
