#ifndef PURCHASEBOX_H
#define PURCHASEBOX_H

#include <QDialog>

namespace Ui {
class purchaseBox;
}

class purchaseBox : public QDialog
{
    Q_OBJECT

signals:
    void getPur(const QString &n, const QString &q);

public:
    explicit purchaseBox(QWidget *parent = nullptr);
    ~purchaseBox();

private slots:
    void pur();

private:
    Ui::purchaseBox *ui;
};

#endif // PURCHASEBOX_H
